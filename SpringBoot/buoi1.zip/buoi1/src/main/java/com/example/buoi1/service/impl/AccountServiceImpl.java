package com.example.buoi1.service.impl;

import com.example.buoi1.entity.Account;
import com.example.buoi1.dto.AccountDTO;
import com.example.buoi1.entity.AccountForm;
import com.example.buoi1.entity.Department;
import com.example.buoi1.repository.IAccountRepository;
import com.example.buoi1.repository.IDepartmentRepository;
import com.example.buoi1.service.IAccountService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Service
public class AccountServiceImpl implements IAccountService {

    @Autowired
    private IAccountRepository accountRepository;
    private IDepartmentRepository departmentRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<AccountDTO> findAll() {
        List<Account> accounts = accountRepository.findAll();

        List<AccountDTO> accountDTOS = new ArrayList<>();
        for (Account account : accounts){
            AccountDTO dto = new AccountDTO();
            dto.setId(account.getId());
            dto.setFullname(account.getFullName());
            dto.setEmail(account.getEmail());
            dto.setUsername(account.getUsername());
        }
        return accountDTOS;
    }

    @Override
    public AccountDTO findById(Integer id) {
        Account account = accountRepository.findById(id).orElse(null);
        if(Objects.isNull(account)){
            throw new RuntimeException("ID not found");
        }
        return modelMapper.map(account, AccountDTO.class);
    }

    @Override
    public void create(AccountForm form) {
        Account account = new Account();
        account.setUsername(form.getUsername());
        account.setFullName(form.getFullname());
        account.setEmail(form.getEmail());
        account.setPassword;

        Department department = departmentRepository.findById(form.getDepartmentId()).orElse(null);
        if (Objects.isNull(department)) {
            throw new RuntimeException("ID ko tồn tại!");
        }
        account.setDepartment(department);
        accountRepository.save(account);
    }

    @Override
    public void update(Integer id, Account accountUpdate) {
        // tìm account theo id muốn update
        Account acc = accountRepository.findById(id).orElse(null);
        if (Objects.isNull(acc)) {
            throw new RuntimeException("ID ko tồn tại!");
        }

        acc.setEmail(accountUpdate.getEmail());
        acc.setUsername(accountUpdate.getUsername());
        acc.setFullName(accountUpdate.getFullName());
        acc.setGender(accountUpdate.getGender());
        acc.setDepartment(accountUpdate.getDepartment());
        acc.setPosition(accountUpdate.getPosition());
        accountRepository.save(acc);
    }

    @Override
    public void deleteById(Integer id) {
        // nếu id không tồn tại thì báo lỗi
        if (!accountRepository.existsById(id)) {
            throw new RuntimeException("ID ko tồn tại!");
        }
        accountRepository.deleteById(id);
    }

}
